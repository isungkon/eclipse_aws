package com.amazonaws.test;

import java.util.List;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.Bucket;

public class S3TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//read credential.
		String profile = "default";
		AWSCredentials credentials = new ProfileCredentialsProvider(profile).getCredentials();
		
		System.out.println(credentials.getAWSSecretKey());
		System.out.println(credentials.getAWSAccessKeyId());
		
		//get s3
		String region = "ap-northeast-2";
		AmazonS3 s3 = AmazonS3ClientBuilder.standard()
			.withCredentials(new AWSStaticCredentialsProvider(credentials))
			.withRegion(region)
			.build();
		List<Bucket> bucketList = s3.listBuckets();
		System.out.println("\nbucket count in region - " + region + " : " + bucketList.size() + "\n=============================");
		for(Bucket bucket : bucketList) {
			System.out.println(bucket.getName() + ", " + bucket.getCreationDate());
		} 
		
	}

}
